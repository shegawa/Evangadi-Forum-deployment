import React from "react";
import classes from "./Question.module.css";
import { Link } from "react-router-dom";
function Question() {
	return (
		<div className={classes.askquestion}>
			<div>
				<div className={classes.askquestion__title}>
					<h3>Steps to write a good question</h3>
					<ul>
						<li>Summerize your problem in one-line title.</li>
						<li>Describe your problem in more detail.</li>
						<li>Describe what you tried and you expect to happen.</li>
						<li>Review your question and post it to the site.</li>
					</ul>
				</div>
				<div className={classes.form__container}>
					<h3>Ask a public question</h3>
					<Link to={"/"}>Go to Question page</Link>
					<form action="">
						<input type="text" placeholder="Title" />

						<textarea
							name="description"
							id="desc"
							rows="6"
							cols="50"
							maxlength="200"
							placeholder="Question Description"
						></textarea>
						<button type="submit">Post your Question</button>
					</form>
				</div>
			</div>
		</div>
	);
}

export default Question;
