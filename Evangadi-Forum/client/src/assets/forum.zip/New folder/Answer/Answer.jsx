import React from "react";
import classes from "./Answer.module.css";
import QuestionCard from "../QuestionCard/QuestionCard";
import { FaArrowAltCircleRight } from "react-icons/fa";

function Answer() {
	return (
		<section className={classes.answer}>
			<section className={classes.answer__container}>
				<div className={classes.answer__title}>
					<h1>QUESTION</h1>
					<div>
						<div>
							<FaArrowAltCircleRight
								size={30}
								style={{ padding: "10px 5px 0px", color: "#516CF0" }}
							/>
							<span>what is bootstrap?</span>
						</div>

						<p>klbnsbnslbknsklbn</p>
					</div>
				</div>
				<hr />
				<div>
					<h1>Answer From The Community</h1>
					<hr />
					<div className={classes.answer__display}>
						<QuestionCard
							flex={false}
							flexsmall={true}
							angle={false}
							avsize={50}
						/>
					</div>
				</div>
				<div>
					<textarea
						name="answer"
						id="answerid"
						placeholder="Your answer"
						rows="6"
						cols={"50"}
					></textarea>
					<button type="submit">Post Answer</button>
				</div>
			</section>
		</section>
	);
}

export default Answer;
