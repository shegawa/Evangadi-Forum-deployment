import React from "react";
import classes from "./QuestionCard.module.css";
import { Link } from "react-router-dom";
import { FaUserCircle } from "react-icons/fa";
import { FaAngleRight } from "react-icons/fa";

function QuestionCard({ flex, flexsmall, angle, avsize }) {
	return (
		<>
			<div className={classes.home__question__display}>
				<div className={classes.home__links}>
					<div
						className={`${classes.home__fauser} ${
							flex ? classes.home__flex : ""
						}`}
					>
						<div>
							<FaUserCircle
								size={avsize}
								style={{ padding: "0 20px 0 10px", margin: "0" }}
							/>
							<p className={classes.qs__user}>Ayu</p>
						</div>
						<div
							className={`${classes.home__title} ${
								flexsmall ? classes.flexsmall : ""
							}`}
						>
							<p>what is bootstrap?</p>
						</div>
					</div>
					{angle && (
						<div>
							<div className={classes.angle__container}>
								<FaAngleRight
									className={classes.angle}
									size={40}
									style={{ paddingTop: "50" }}
								/>
							</div>
						</div>
					)}
				</div>
			</div>
			<hr />
		</>
	);
}

export default QuestionCard;
