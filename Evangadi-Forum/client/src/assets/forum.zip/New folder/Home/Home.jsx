import React, { useContext } from "react";
import { AppState } from "../../App";
import { Link } from "react-router-dom";
import classes from "./Home.module.css";

import QuestionCard from "../QuestionCard/QuestionCard";

function Home() {
	const { user } = useContext(AppState);
	return (
		<section className={classes.home}>
			<div className={classes.home__container}>
				<div className={classes.home__wellcome}>
					<div className={classes.home__question}>
						<p>
							<Link to={"/askquestion"}>Ask Question</Link>
						</p>
					</div>
					<div>
						<h2>
							Wellcome: <span>{user.username}</span>
						</h2>
					</div>
				</div>
				<div className={classes.home__input}>
					<input type="text" placeholder="Search Question" />
				</div>
				<hr />
				<Link to="/answer">
					<QuestionCard
						flex={true}
						flexsmall={false}
						angle={true}
						avsize={100}
					/>
				</Link>
			</div>
		</section>
	);
}

export default Home;
